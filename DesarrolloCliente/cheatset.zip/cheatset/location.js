location.href;            // devuelve la URL completa
location.hostname;        // devuelve el dominio
location.pathname;        // devuelve la ruta del archivo
location.search;          // devuelve la cadena ?query
location.hash;            // devuelve el fragmento #id

location.reload();        // recarga la página
location.assign(url);     // navega a otra URL
