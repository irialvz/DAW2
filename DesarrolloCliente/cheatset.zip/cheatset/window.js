window.innerWidth;        // ancho del área visible
window.innerHeight;       // alto del área visible

window.open(url);         // abre una nueva ventana/pestaña
window.alert("msg");      // muestra una alerta
window.setTimeout(fn,ms); // ejecuta una función una vez después del tiempo
window.setInterval(fn,ms);// ejecuta periódico cada intervalo
