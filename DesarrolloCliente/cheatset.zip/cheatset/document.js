document.getElementById("id");        // selecciona por ID
document.querySelector(".class");     // selecciona el primer elemento que coincida
document.querySelectorAll("p");       // selecciona todos los elementos que coincidan

document.createElement("div");        // crea un elemento en memoria
document.body.appendChild(node);      // añade un elemento al DOM

document.title;                       // obtiene o cambia el título
document.cookie;                      // gestiona las cookies
