navigator.userAgent;      // devuelve info del navegador y sistema
navigator.language;       // idioma del navegador
navigator.onLine;         // indica si hay conexión a internet
navigator.geolocation.getCurrentPosition(fn);
// obtiene la ubicación (con permiso)
