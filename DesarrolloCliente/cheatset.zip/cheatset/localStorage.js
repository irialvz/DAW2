localStorage.setItem("key", "value");   // guarda un valor
localStorage.getItem("key");            // recupera un valor
localStorage.removeItem("key");         // elimina un valor
localStorage.clear();                   // borra todo
