screen.width;             // ancho total de la pantalla
screen.height;            // alto total de la pantalla
screen.availWidth;        // ancho disponible para la ventana
screen.availHeight;       // alto disponible para la ventana
screen.colorDepth;        // profundidad de color
