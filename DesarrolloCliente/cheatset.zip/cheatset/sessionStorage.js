sessionStorage.setItem("key", "value");  // guarda un valor
sessionStorage.getItem("key");           // recupera un valor
sessionStorage.removeItem("key");        // elimina un valor
sessionStorage.clear();                  // borra todo
