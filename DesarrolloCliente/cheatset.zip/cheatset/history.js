history.back();           // navega a la página anterior
history.forward();        // avanza a la siguiente página
history.go(-2);           // se mueve N pasos en el historial
history.length;           // número de entradas en la sesión
